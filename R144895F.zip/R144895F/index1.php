

<!DOCTYPE html>
<html>
<center>
<div id="logo">
<img id="logo"src="buffalo.jpg"alt="WE ARE TREKORS"float:left/>
</div>
<div id="name">WE ARE TREKORS</div>
</center>
<head>
<title>TREKOR PETROL-SYSTEM-ONLINE-FORMS
</title>
<hr>
<link rel="stylesheet" href="css/Bootstrap.css" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript" src="js/regis.js"></script
<script src="js/jquery-2.2.3.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.js"></script>  
  <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>  
  <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.3/css/bootstrapValidator.min.css"/>
  <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.3/js/bootstrapValidator.min.js"> </script>
</
$(document).ready(function() {
    $('#contactForm').bootstrapValidator({
        container: '#messages',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            fullName: {
                validators: {
                    notEmpty: {
                        message: 'The full name is required and cannot be empty'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: 'The email address is required and cannot be empty'
                    },
                    emailAddress: {
                        message: 'The email address is not valid'
                    }
                }
            },
            title: {
                validators: {
                    notEmpty: {
                        message: 'The title is required and cannot be empty'
                    },
                    stringLength: {
                        max: 100,
                        message: 'The title must be less than 100 characters long'
                    }
                }
            },
            content: {
                validators: {
                    notEmpty: {
                        message: 'The content is required and cannot be empty'
                    },
                    stringLength: {
                        max: 500,
                        message: 'The content must be less than 500 characters long'
                    }
                }
            }
        }
    });
});





</script>
<style>
</style>
</head>
<marquee><h>TREKOR PETROLEUM SYSTEM</h></marquee>
<body >
<h>TREKOR PETROLEUM SYSTEM ,WE PROVIDE QUALITY SERVICES</h>

	<h1>TREKOR PETROLEUM SYSTEM</h1>
	<hr>
<div id="container">
	
	<header role="banner" id="main-header">
		<div id="logo">
		</div>
		
		<nav id="main_nav">
			<ul>
				<li><a href="project.html">Home</a></li>
				<li><a href="project.html">Register</a></li>5 
				
			</ul>
		</nav>
	</header>
	<section id="content">		
	</section>
	<div id="clearfix"></div>
	<div id="clearfix"></div>
</div>

<p>	
       <nav id="left_nav">
              <div class="form-group">

                     <form class="form-horizontal" action="signUp.php" method="post">
                            <h4> ONLINE-REGISTRATION-FORMS </h4>
							
						
                            <label>COMPANY NAME :</label>
                            <input type="text" name="trkcompany" id="company"placeholder="company name"required><br>
                            <label>EMAIL :</label>
                            <input type="text" name="email" id="email"placeholder="ENTER EMAIL"required><br>
							<label>PHONE NUMBER :</label>
							<input type="text" name="phone" id="email"placeholder="**********"required><br>
							<label>DATE:</label>
							<input type="date" name="date" id="email"required><br>
							 <label>LOCAL COMPANIES:</label>
                            <label>COMMERCIAL USE:</label>
                            <input type="radio" name="customer" id="commercial"required>
                            <label>PRIVATE USE :</label>
                            <input type="radio" name="customer" id="private"required><br>
							 <label>FOREIGN COMPANIES:</label>
							 <label>COMMERCIAL USE:</label>
                            <input type="radio" name="trkcommercial" id="commercial"required><br>
							<p><h2>PETROLEUM TYPE</h2></p>
							<select>
							 
                            <option value="petrol">petrol</option>
							<option value="diesiel">diesiel</option>
						
							<input type="radio" name="fuel" id="petrol"/><br>
                            <p><h3>Payment Method</h3></p>
							</select>
							<select>
							
							<option name="payment" value="coupon">coupon</option>
							<option name="payment" value="cash">cash</option><br>
							</select>
                            <p><h3>CURRENCE</h3></p><hr>
							<label>USD DOLLARS :</label>
							<input type="radio" name="cash" id="USD">
							<label>S.A RANDS :</label>
                            <input type="radio" name="cash" id="RANDS"><br>
                           
                            <label>COMPANY REGISTRATION NUMBER:</label>
                            <input type="text" name="CompanyReNumber" id="companyReNgumber"placeholder="**********" required><br>
                            <label>PASSWORD :</label>
                            <input type="password" name="password" id="password"placeholder="**********"required><br>
                            <label>CONFIRM PASSWORD :</label>
                            <input type="password" name="Password" id="password"required>
							</div class="form-group">
							 <div class="checkbox">
    <label>
      <input type="checkbox"required> Check me out
    </label>
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
</form group>
                            
<div>

<img src="iimges A.jpg"alter="TREKOR CUSTOMER"><br>
<img src="images.jpg"alter="TREKOR CUSTOMER">
</div>
              </div>
       </nav> 
	    <input type="radio" name="cash" id="RANDS"required><h6>I AGREE WITH TERMS AND CONDITIONS ABINDING THIS FORM</h6>><br>
		
	   
</body>
<marquee><h5>TREKOR PETROL SYSTEM</h5></marquee>
</html>

