<?php
 
 $cName =$_POST["trkcompany"];
 $password =$_POST["Password"];

$email =$_POST["email"];
$phone =$_POST["phone"];
//$payment =$_POST["payment"];
$date =$_POST["date"];
$companyReg =$_POST["CompanyReNumber"];


	 echo"Company Name: $cName <br>";
	 echo"Password: $password <br>";
	//echo"Payment Method: $payment <br> ";
	echo"Email: $email <br>";
	echo"Phone: $phone <br>";
	echo"Date: $date <br>";
	echo"Company RegNumber: $companyReg<br><br>";
	
	
	 ?>
	<html>
		<body>
		<h1>Now login</h1>
			<form action="log.php" method="post">
<label for="username" > Username</label>
<input type="text" name="username"><br>

<label for="password" >password</label>
<input type="password" name="password"><br>
<input type="submit" value="login">

</form>
		</body>
	
	</html>