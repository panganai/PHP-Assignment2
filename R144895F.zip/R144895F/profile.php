<html>

<?php
echo"welcome ".($_GET['username']);

?>
<body>
<h2>this is your page Mr General</h2>
</body>
</html>