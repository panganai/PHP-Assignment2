<?php
 
 
 if($_POST['username']=='general' && $_POST['password']=='0000'){
	 
	 ?>
	 <a href="profile.php?username=<?php echo $_POST['username']?>">
	 correct logged in go to profile page
	 </a>
	 <?php
 }
else{
	?>
		<a href="index1.php">log in failure go home </a>
		<?php
}

?>